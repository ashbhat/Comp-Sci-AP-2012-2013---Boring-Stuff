import java.util.Scanner;
/**
 * Write a description of class Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tester
{
    public static void main(String [] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a sentance ending in a period");
        String in;
        do
        {
            in = input.next();
            Word w = new Word(in);
            int Syllables = w.countSyllables();
            System.out.println("Syllables in " + in + ": " + Syllables);
            if (in == "end")
            {
                break;    
            }    
    }while (!in.endsWith("."));    
    
}}
