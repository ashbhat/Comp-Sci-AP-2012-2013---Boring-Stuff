
/**
 * Write a description of class QuadraticTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class QuadraticTester
{
    public static void main(String[] args)
    {
        Quadratic myQuad = new Quadratic( 1, 1, 6);
        System.out.println(myQuad.getSolution1() + " " + myQuad.getSolution2());
        System.out.println("Does this have solutions?: " + myQuad.hassolutions() );
    }    
}
