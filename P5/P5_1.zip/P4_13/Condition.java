
/**
 * Write a description of class Condition here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Condition
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Condition
     */
    public Condition()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public String sampleMethod()
    {
        x = 3;
        y = 5;
        if (x<y)
        {
            x=x;
            y=y;
        }    
        else if(x>y)
        {
            double a = x;
            x = y;
            y = a;
        }   
        
        String j = (x +  " " + y); 
        return j;
    }
}
