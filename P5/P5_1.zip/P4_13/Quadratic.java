import java.lang.Math;

/**
 * Write a description of class Quadratic here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Quadratic
{
    // instance variables - replace the example below with your own
    private double a;
    private double b;
    private double c;
    private double x;
    private double d;
    private double e;
    private double f;
    private String hi;
    boolean real;

    /**
     * Constructor for objects of class Quadratic
     */
    public Quadratic(double w, double y, double z)
    {
        a = w;
        b = y;
        c = z;
    }
       
    // quadratic formula is axsqrd + bx + c = 0
    public String getSolution1()
    {
       if ((Math.pow(b,2) - 4*a*c)<0)
       {
           x = 0;
           hi = (x + " Unreal! Not a real solution :(");
       }
       else
       {
       d = ((-b) + Math.sqrt(Math.pow(b,2) - 4*a*c))/(2*a);
       real = true;
       hi = ("Your first root is " + d); 
    }
       return hi;
       
    }
    
    public String getSolution2()
    {
       if ((Math.pow(b,2) - 4*a*c)<0)
       {
           x = 0;
           hi = ("");
       }
       else 
       {
       x = ((-b) - Math.sqrt(Math.pow(b,2) - 4*a*c))/(2*a);
       real = true;
       hi = ("and your second root is " + x); 
       }
       return hi;
    }
    
    public boolean hassolutions()
    {
        if (x==0){
        real = false;
    }
        else{
        real = true;}
        return real;
    }    
}
