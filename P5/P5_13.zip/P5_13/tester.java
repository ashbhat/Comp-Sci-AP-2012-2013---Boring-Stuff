import java.util.Scanner;
/**
 * Write a description of class tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class tester
{
    public static void main(String [] args)
    {
       Scanner input = new Scanner(System.in);
       System.out.println("What is your hourly wage. Please be as accurate as possible.");
       double wage = input.nextDouble(); 
       System.out.println("alright, if you say so. Now, how many hours have you worked this week? Coffee breaks don't count.");
       double hours = input.nextDouble();
       paycheck mine = new paycheck(wage,hours);
       System.out.println("Good job! We've computed your earnings for this week! $" + mine.getMoney());
    }    
}
