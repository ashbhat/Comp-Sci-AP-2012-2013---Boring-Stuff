
/**
 * Write a description of class Employee here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class paycheck
{
    // instance variables - replace the example below with your own
    private double x;
    private double y;
    private double z;
    /**
     * Constructor for objects of class Employee
     */
    public paycheck(double wage, double hours)
    {
        x = wage;
        y = hours;
        if (hours > 40)
        {
            z = 40*wage + (hours - 40)*1.5*wage;    
        }    
        else
        {
            z = hours*wage;
        }    
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public double getMoney()
    {
        return z;
    }
}
