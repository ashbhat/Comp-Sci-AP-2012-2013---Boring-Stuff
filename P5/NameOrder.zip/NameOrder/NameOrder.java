
/**
 * Write a description of class NameOrder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NameOrder
{
    // instance variables - replace the example below with your own
    private String x;
    private String y;
    private String z;
    private String k;
    /**
     * Constructor for objects of class NameOrder
     */
    public NameOrder(String a, String b, String c)
    {
        if (a.compareTo(b) > 0)
        {
            k = a;
            if (a.compareTo(c) > 0)
            {
                x = a;
                if (b.compareTo(c) > 0)
                {
                    y = b;
                    z = c;
                } 
                else
                {
                    z = b;
                    y = c;
                }    
            }
            else
            {
                x = c;
                y = a;
                z = b;
            }    
        }
        else 
        {
            if (b.compareTo(c) > 0)
            {
               
                if (a.compareTo(c) > 0)
                {
                    x = b;
                    y = a;
                    z = c;
                }    
                else 
                {
                    x = b;
                    y = c;
                    z = a;
                }    
            }
            else
            {
                x = c;
                y = b;
                z = a;
            }  
        }
        
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public String getNames()
    {
        return (z + " " + y + " " + x + " ");
    }
}
