import java.util.Scanner;
/**
 * Write a description of class NameOrderTester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NameOrderTester
{
    public static void main (String [] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("What's the first name?");
        String a = input.nextLine();
        System.out.println("What's the second name?");
        String b = input.nextLine();
        System.out.println("What's the third name?");
        String c = input.nextLine();
        NameOrder ournames = new NameOrder(a, b, c);
        System.out.println(ournames.getNames());
        
    }    
}
