
/**
 * Write a description of class Power here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Power
{
    // instance variables - replace the example below with your own
    private int x = -1;
    private double a;
    private String numbers ="Here are your numbers";
    /**
     * Constructor for objects of class Power
     */
    public Power(double aFactor)
    { 
        for (int i = 1; i <=12; i++){
        x = x + 1;
        a = Math.pow(aFactor, x);
        numbers = numbers + "\n" + a;
    }
    }
    public String nextPower()
    {
        return numbers;
    } 
    public static void main(String [] args)
    {
        Power bob = new Power(10);
        System.out.println(bob.nextPower()); 
    }    
}
