import java.util.ArrayList;

class Purse{
    ArrayList<Integer> coins;

    public Purse(){
        coins = new ArrayList<Integer>();
    }
    
    public void addCoin(int coinName){
        coins.add(coinName);
    }
    
    public String toString()
    {
        System.out.println("Purse" + coins);
        return "";
    }
    public void reverse(){
        int lastSlot = coins.size() - 1;
        /*for(int i = 0; i <= lastSlot; i++){
            String last = coins.get(lastSlot);
            coins.add(i, last);
            coins.remove(lastSlot + 1);
        }*/
    }
    public void alternate()
    {
        int lastSlot = coins.size() - 1;
        int b = 0;
        int j = 1;
        for(int i = 0; i <= lastSlot - 1;)   
        {
            
            b = b + coins.get(i) - coins.get(j);
            i = i + 2;
            j = j + 2;
        }    
        System.out.println("The total is " + b);
    }
}