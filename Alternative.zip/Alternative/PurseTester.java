public class PurseTester
{
   public static void main(String[] args)
   {
      Purse p = new Purse();
      p.addCoin(1);
      p.addCoin(2);
      p.addCoin(3);
      p.addCoin(4);
      //p.reverse();
      //System.out.println(p.toString());
      //System.out.println("Expected: Purse[Quarter,Dime,Nickel,Dime]");
      p.alternate();
   }
}
